class AssertMessage:

    VERIFY_WRONG_MESSAGE = 'Verification Code Error. Please make sure to enter the latest verification code you received.'