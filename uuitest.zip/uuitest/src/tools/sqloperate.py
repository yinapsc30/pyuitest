import pymysql


class SqlOperate:

    def __init__(self, sql):
        # 连接到数据库
        connection = pymysql.connect(host='localhost',
                                     user='user',
                                     password='password',
                                     db='database',
                                     charset='utf8mb4')

        try:
            # 获取会话指针
            with connection.cursor() as cursor:
                # 执行 SQL 语句
                cursor.execute(sql)
                # 获取所有记录
                result = cursor.fetchall()
                print(result)
        finally:
            # 关闭连接
            connection.close()

    def get_withdraw_verity_code(self):
        ...
